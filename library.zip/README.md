vk_api
======

**vk_api** - модуль для использования API сайта ВКонтакте (vk.com). Пример смотрите в файле [example.py](https://github.com/python273/vk_api/blob/master/example.py)

Тестовая поддержка **Python 3**!

С вопросами или советами можете [написать автору в ВК](https://vk.com/im?sel=183433824).

Установка
------------
    $ easy_install vk_api

Для работы необходим модуль [Requests](https://github.com/kennethreitz/requests)

    $ easy_install requests
